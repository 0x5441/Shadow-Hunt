chrome.action.onClicked.addListener((tab) => {
  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: myCustomScript
  });
});

function myCustomScript() {
  let likeIndex = 0;
  function likeAndScroll() {
    const likes = document.querySelectorAll('[data-testid="like"]');
    let likedThisRound = 0;
    for (; likeIndex < likes.length && likedThisRound < 4; likeIndex++, likedThisRound++) {
      likes[likeIndex].click();
    }
    if (likedThisRound > 0) {
      setTimeout(() => {
        // Scroll smoothly like mouse wheel
        let scrollAmount = window.innerHeight * 0.75;
        let scrolled = 0;
        let step = 40;
        function smoothScroll() {
          if (scrolled < scrollAmount) {
            window.scrollBy(0, step);
            scrolled += step;
            setTimeout(smoothScroll, 10);
          } else {
            setTimeout(likeAndScroll, 2000);
          }
        }
        smoothScroll();
      }, 1000);
    } else {
      setTimeout(likeAndScroll, 2000);
    }
  }
  likeAndScroll();
}
